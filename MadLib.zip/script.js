// detects if the button is pressed
document.getElementById("buttonInput").addEventListener("click", output);

// get the input
// function activates, when you press the button, and it changes the innerhtml of the mainparagraph
function output() {
    // variable schoolsubject, takes the value of the input, and gives it to the variable everything
    let SchoolSubject = document.getElementById("schoolS").value;
    // also gives value of color, and gives it to everything
    let ColorOfNoun = document.getElementById("color").value;
    // also gives value of noun, and gives it to everything
    let Noun = document.getElementById("noun").value;
    // joins all the variables, and then gives it to document.getElementById, and changes the MainParagraph
    let everyThing = ("In " + SchoolSubject + " class, our teacher was wearing a " + ColorOfNoun + " " + Noun + ".");
    // changes the mainParagraph to everyThing
    document.getElementById("mainParagraph").innerHTML = everyThing;
}